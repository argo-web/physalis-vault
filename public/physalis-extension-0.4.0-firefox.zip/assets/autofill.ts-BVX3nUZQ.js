(function(){function E(e=document){return Array.from(e.querySelectorAll('input[type="password"]')).filter(S).map(n=>({password:n,username:k(n)}))}function S(e){if(e.disabled||e.readOnly||e.type==="hidden")return!1;if(e.offsetParent===null&&e.type!=="hidden"){const t=e.getBoundingClientRect();if(t.width===0&&t.height===0)return!1}return!0}function k(e){var r,s;const t=P(e);if(t.length===0)return null;for(const i of t)if(((r=i.autocomplete)==null?void 0:r.toLowerCase())==="username")return i;for(const i of t)if(((s=i.autocomplete)==null?void 0:s.toLowerCase())==="email")return i;for(const i of t)if(i.type==="email")return i;const n=/(user|email|login|mail|account|identif)/i;for(const i of t)if(n.test(i.name)||n.test(i.id))return i;const o=t.filter(i=>i!==e&&!!(e.compareDocumentPosition(i)&Node.DOCUMENT_POSITION_PRECEDING));return o.length>0?o[o.length-1]??null:t[0]??null}function P(e){const t='input:not([type="password"]):not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="checkbox"]):not([type="radio"]):not([type="file"])',n=e.form;let o=[];if(n)o=Array.from(n.querySelectorAll(t));else{let r=e.parentElement;for(;r&&o.length===0;)o=Array.from(r.querySelectorAll(t)),r=r.parentElement}return o.filter(S)}const M=/confirm|verify|repeat|retype|again|nouveau|nouvel/i;function I(e){const t=[e.id,e.name,e.placeholder,e.autocomplete,e.getAttribute("aria-label")??""].join(" ").toLowerCase();return M.test(t)}function T(e){const t=Array.from(e.querySelectorAll('input[type="password"]'));for(const n of t)if(!I(n)&&n.value)return n;return null}function $(e){const t=e.querySelector('input[autocomplete="username"]');if(t!=null&&t.value)return t.value.trim();const n=e.querySelector('input[autocomplete="email"]');if(n!=null&&n.value)return n.value.trim();const o=e.querySelector('input[type="email"]');if(o!=null&&o.value)return o.value.trim();const r=Array.from(e.querySelectorAll('input:not([type="password"]):not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="checkbox"]):not([type="radio"]):not([type="file"])'));for(const s of r)if(!I(s)&&s.value&&s.value.trim())return s.value.trim();return""}function O(e,t){const n=Object.getPrototypeOf(e),o=Object.getOwnPropertyDescriptor(n,"value");o!=null&&o.set?o.set.call(e,t):e.value=t}function g(e,t){O(e,t),e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}))}const A="sv-save-prompt-host",C=15e3;let m=null;function v(){m&&(clearTimeout(m),m=null);const e=document.getElementById(A);e&&e.remove()}function N(e,t){var a,l;v();const n=document.createElement("div");n.id=A,n.style.cssText=["all: initial","position: fixed","top: 16px","left: 50%","transform: translateX(-50%)","z-index: 2147483647","pointer-events: none"].join(";");const o=n.attachShadow({mode:"closed"});o.innerHTML=`
    <style>${D}</style>
    <div class="banner" role="dialog" aria-live="polite">
      ${_(e)}
    </div>
  `,document.documentElement.appendChild(n);const r=o.querySelector(".banner");r.style.pointerEvents="auto",requestAnimationFrame(()=>r.classList.add("shown"));const s=o.querySelector('input[name="never-again"]'),i=()=>{r.classList.remove("shown"),setTimeout(()=>v(),200)};(a=o.querySelector('[data-action="save"]'))==null||a.addEventListener("click",()=>{i(),t.onSave()}),(l=o.querySelector('[data-action="ignore"]'))==null||l.addEventListener("click",()=>{const d=(s==null?void 0:s.checked)??!1;i(),t.onIgnore({neverAgain:d})}),m=setTimeout(()=>{i(),t.onIgnore({neverAgain:!1})},C)}function _(e){const t=chrome.runtime.getURL("icons/icon-48.png");return e.kind==="new"?`
      <div class="row">
        <img class="icon" src="${y(t)}" alt="" />
        <div class="content">
          <div class="title">Enregistrer ce mot de passe ?</div>
          <div class="meta">
            <strong>${p(e.url)}</strong>
            ${e.username?` · ${p(e.username)}`:""}
          </div>
          <label class="never-again">
            <input type="checkbox" name="never-again" />
            Ne plus demander pour ce site
          </label>
        </div>
        <div class="actions">
          <button class="btn-ghost" data-action="ignore" type="button">Ignorer</button>
          <button class="btn-primary" data-action="save" type="button">Enregistrer</button>
        </div>
      </div>
    `:`
    <div class="row">
      <img class="icon" src="${y(t)}" alt="" />
      <div class="content">
        <div class="title">Mettre à jour le mot de passe ?</div>
        <div class="meta">
          <strong>${p(e.url)}</strong>
          ${e.username?` · ${p(e.username)}`:""}
        </div>
        <div class="existing">
          Entrée existante : <em>${p(e.existing.name)}</em>
        </div>
      </div>
      <div class="actions">
        <button class="btn-ghost" data-action="ignore" type="button">Ignorer</button>
        <button class="btn-primary" data-action="save" type="button">Mettre à jour</button>
      </div>
    </div>
  `}function p(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function y(e){return e.replace(/"/g,"&quot;")}const D=`
:host { all: initial; }
.banner {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  font-size: 13px;
  background: #f5f3ef;
  color: #1a1a1a;
  border: 1px solid #e5e0d6;
  border-radius: 14px;
  box-shadow: 0 12px 40px -12px rgba(31,31,31,0.25);
  padding: 14px 16px;
  min-width: 420px;
  max-width: 520px;
  opacity: 0;
  transform: translateY(-12px);
  transition: opacity 0.2s ease, transform 0.2s ease;
}
.banner.shown { opacity: 1; transform: translateY(0); }
.row { display: flex; align-items: flex-start; gap: 12px; }
.icon {
  width: 28px; height: 28px; flex-shrink: 0;
  margin-top: 2px;
}
.content { flex: 1; min-width: 0; }
.title { font-weight: 700; font-size: 14px; margin-bottom: 4px; }
.meta {
  font-size: 12px; color: #7a7167;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.meta strong { color: #c9943f; font-weight: 600; }
.existing {
  font-size: 11px; color: #7a7167; margin-top: 6px;
}
.existing em { color: #1a1a1a; font-style: normal; font-weight: 600; }
.never-again {
  display: flex; align-items: center; gap: 6px;
  font-size: 11px; color: #7a7167; margin-top: 8px; cursor: pointer;
  user-select: none;
}
.never-again input { margin: 0; cursor: pointer; }
.actions {
  display: flex; gap: 8px; align-items: center; flex-shrink: 0;
}
button {
  font: inherit; font-size: 12px; font-weight: 600;
  padding: 7px 13px;
  border-radius: 8px; cursor: pointer; border: 1px solid transparent;
}
.btn-primary {
  background: #1f1f1f; color: #d4a149; border-color: #1f1f1f;
}
.btn-primary:hover { background: #3a3a3a; }
.btn-ghost {
  background: transparent; color: #7a7167; border-color: #d4cdc0;
}
.btn-ghost:hover { background: #efeae0; color: #1a1a1a; }
`,u=22,q=6;let c=[];const f=new WeakMap,h=new Set;function F(){if(location.protocol!=="http:"&&location.protocol!=="https:")return;const e=location.hostname;if(e==="secretvault.argoweb.fr"||e==="physalis.cloud"||e.endsWith(".physalis.cloud")||e==="localhost"||e==="127.0.0.1"){const r=chrome.runtime.getManifest().version;document.documentElement.dataset.secretvaultExt=r,document.dispatchEvent(new CustomEvent("secretvault-extension-ready",{detail:{version:r}}))}w(),(async()=>{const r=await chrome.runtime.sendMessage({type:"GET_PENDING_SAVE",payload:{domain:location.hostname}}).catch(()=>null);r&&typeof r=="object"&&r.ok&&r.data&&b(r.data)})(),chrome.runtime.onMessage.addListener((r,s,i)=>{const a=r;if((a==null?void 0:a.type)==="FILL_PAGE"){const l=a.payload,d=H(l);return i({ok:!0,data:{filled:d}}),!1}if((a==null?void 0:a.type)==="FILL_TOTP"){const l=a.payload,d=V(l.code);return i({ok:!0,data:{filled:d}}),!1}return(a==null?void 0:a.type)==="SHOW_PROMPT"&&(b(a.payload),i({ok:!0,data:null})),!1}),document.addEventListener("submit",U,!0),window.addEventListener("beforeunload",()=>v()),new MutationObserver(x(w,250)).observe(document.documentElement,{childList:!0,subtree:!0});const o=x(R,50);window.addEventListener("scroll",o,{passive:!0,capture:!0}),window.addEventListener("resize",o)}function w(){const e=E(document);new Set(e.map(t=>t.password));for(const t of h){if(!t.dataset.svFor)continue;e.some(o=>f.get(o.password)===t)||(t.remove(),h.delete(t))}c=e;for(const t of c)if(t.password.isConnected){if(!f.has(t.password)){const n=j();document.body.appendChild(n),f.set(t.password,n),h.add(n)}L(f.get(t.password),t.password)}}function R(){for(const e of c){const t=f.get(e.password);t&&e.password.isConnected&&L(t,e.password)}}function L(e,t){const n=t.getBoundingClientRect();if(n.width===0&&n.height===0){e.style.display="none";return}e.style.display="";const o=window.scrollY+n.top+(n.height-u)/2,r=window.scrollX+n.right-u-q;e.style.top=`${o}px`,e.style.left=`${r}px`}function j(){const e=document.createElement("button");e.type="button",e.dataset.svFor="autofill",e.setAttribute("aria-label","Physalis — voir les credentials"),e.title="Physalis",e.style.cssText=["all: initial","position: absolute","z-index: 2147483647","cursor: pointer",`width: ${u}px`,`height: ${u}px`,"box-sizing: border-box","display: inline-flex","align-items: center","justify-content: center"].join(";");const t=document.createElement("img");return t.src=chrome.runtime.getURL("icons/icon-48.png"),t.alt="",t.style.cssText=["all: initial",`width: ${u}px`,`height: ${u}px`,"pointer-events: none","display: block"].join(";"),e.appendChild(t),e.addEventListener("mousedown",n=>n.preventDefault()),e.addEventListener("click",n=>{n.preventDefault(),n.stopPropagation(),z()}),e}async function z(){await chrome.runtime.sendMessage({type:"OPEN_POPUP",payload:{domain:window.location.hostname}})}function U(e){const t=e.target;if(!t||t.tagName!=="FORM")return;const n=t,o=T(n);if(!o)return;const r=$(n);chrome.runtime.sendMessage({type:"FORM_SUBMITTED",payload:{url:window.location.hostname,username:r,password:o.value}})}function b(e){const t=()=>{chrome.runtime.sendMessage({type:"CLEAR_PENDING_SAVE",payload:{domain:e.url}})};N(e,{onSave:()=>{t();const n="personal",o=G(e.url,e.username);chrome.runtime.sendMessage(e.kind==="update"?{type:"SAVE_CREDENTIAL",payload:{action:"update",id:e.existing.id,target:e.existing.target,orgSlug:e.existing.orgSlug,projectSlug:e.existing.projectSlug,collectionSlug:e.existing.collectionSlug,name:e.existing.name,url:e.existing.url||`https://${e.url}`,username:e.username||e.existing.username,password:e.password,tags:e.existing.tags}}:{type:"SAVE_CREDENTIAL",payload:{action:"create",target:n,name:o,url:`https://${e.url}`,username:e.username,password:e.password}})},onIgnore:({neverAgain:n})=>{t(),n&&chrome.runtime.sendMessage({type:"IGNORE_DOMAIN",payload:{domain:e.url}})}})}function G(e,t){return t?`${e} (${t})`:e}function H(e){if(c.length===0&&(c=E(document)),c.length===0)return!1;const t=c[0];return t.username&&g(t.username,e.user),g(t.password,e.password),!0}function V(e){const t=document.querySelector('input[autocomplete="one-time-code"]');if(t)return g(t,e),!0;const n=document.querySelectorAll('input[type="text"], input[type="number"], input[type="tel"]');for(const o of n){const r=`${o.id} ${o.name} ${o.autocomplete}`.toLowerCase();if(/(?:^|[^a-z])(otp|totp|2fa|verification|verify)/i.test(r))return g(o,e),!0}return!1}function x(e,t){let n=0,o=null;return(...r)=>{const s=Date.now(),i=t-(s-n);i<=0?(o&&(clearTimeout(o),o=null),n=s,e(...r)):o||(o=setTimeout(()=>{n=Date.now(),o=null,e(...r)},i))}}F();
})()
